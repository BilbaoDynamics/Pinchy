#ifndef PinchyWifi_h
#define PinchyWifi_h

#include "Arduino.h"

class PinchyWifi
{
  public:
    void http(String output);
    void webServer(void);
};

#endif
